//
//  main.m
//  TestObjcBuild
//
//  Created by Yoyo on 2021/1/5.

#import <Foundation/Foundation.h>
#import "TestBase.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        // insert code here...
        /*
         alloc LLVM 编译 （llvm优化alloc：https://www.imgeek.org/article/825357699）
         先走 symbol objc_alloc
         再走到 + (id)alloc
         */
        TestBase *test = [TestBase alloc];
//        [test init];
        NSLog(@"iOS");
    }
    return 0;
}
