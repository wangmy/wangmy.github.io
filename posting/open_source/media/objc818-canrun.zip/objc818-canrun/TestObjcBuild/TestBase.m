//
//  TestBase.m
//  TestObjcBuild
//
//  Created by wangmingyou on 2022/2/18.
//

#import "TestBase.h"

@implementation TestBase

@end
