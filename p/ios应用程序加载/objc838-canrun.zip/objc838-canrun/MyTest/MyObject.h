//
//  MyObject.h
//  MyTest
//
//  Created by 王明友 on 2022/2/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MyObject : NSObject

@end

NS_ASSUME_NONNULL_END
