//
//  MyObject.m
//  MyTest
//
//  Created by 王明友 on 2022/2/21.
//

#import "MyObject.h"

@implementation MyObject

@end
