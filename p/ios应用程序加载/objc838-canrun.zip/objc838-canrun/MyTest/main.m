//
//  main.m
//  MyTest
//
//  Created by 王明友 on 2022/2/21.
//

#import <Foundation/Foundation.h>
#import "MyObject.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        [MyObject alloc];
    }
    return 0;
}
