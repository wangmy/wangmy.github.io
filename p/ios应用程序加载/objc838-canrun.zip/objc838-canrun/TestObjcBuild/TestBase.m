//
//  TestBase.m
//  TestObjcBuild
//
//  Created by 王明友 on 2022/2/21.
//

#import "TestBase.h"

@implementation TestBase

@end
