//
//  main.m
//  TestObjcBuild
//
//  Created by 王明友 on 2022/2/21.
//

#import <Foundation/Foundation.h>
#import "TestBase.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        TestBase *test = [TestBase alloc];
        NSLog(@"iOS!");
    }
    return 0;
}
